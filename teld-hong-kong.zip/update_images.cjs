const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

const imageUpdates = {
  "上海11路/26路公交智能充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdqrbTn5QoJNAoZT4grjUvxEy4W0ztyt5okJQZuGZQU61EYrxH_uRIi74jxcb_RPcHxtlfjgQGr7JOreAjvFTJJzjsnKUdYPTdxP1D5HjIaWtvuNxZ_V5onnVMWsR7fwctmi0Ga_SsLAyf_YXyBlhjLEr16gbg?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海奉賢公交南橋充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcw9SLdudTUbWiQc5lkvRuqIIp331bihEooJPYvHMM2zAlYmeOhD19yFsg4tzl94-whRqxFH4kG8eaCa-QlpBjeHWKhCaJFavoRgaRNxepwb5RaknwEQ-2a780-GJmb9ypdIeG5RihSIlWj66uj8GN0YcwapnY?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海強生漕寶停車場生態復用站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXd6xfBhDApVtabzF8UiBQN_zSBxVQMRQF2zm89ulzxSxRJIkx78P6E_CT9FVyTmCMbkkXlCNfDDe5pIi1WVZ8enFEhYYMtTbCi6fGukIFbvzSiozm1W1fX8yO1eCLs2Wk3k469iigygKJL-YsxFbJzW1skkWiU?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "四川省九寨溝自然保護區充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdFRw1C5Zbdb5I9OvoIHtgQ7-LU1JAPwUeq0__c6xr-Kcd457q4T156rQVNX5Sha4N5JTWl0SDjg-Kwzr2376JQf_OaIeC1lEgaBrb7YeMOo9Pb5RYpOvEIrIy8iF3KHL_Z1MPZ1aNN4Z2gYm0ihQfrBs0SmIY?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "成都公交充電網": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfSTZmVI4ppDbBi1PQbVUzN18-mo36cQ8jvwdq-64oo85une7KvxgFCzopONfX9sTNqYAyxSMkVdGRwSLBAiQQxboR4vc-u8eZ5F-rRutRLDuWVPSHnEdRx4xi6kpPif2SpamT312xkKZdRHsJu0vSaY59Egjk?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "深圳特來電國際會展中心充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcpPK3WQK6qMcouv8CNQAQIwP946L9T_9RuOMItzmw-2pQjebSDkbhkBcBb3iRAM9of5qA8CBN_9YceVwdPvvFhdnJhooFBIpoxYtUAtmeWDGCK1CYKNCV73Pmbukemr2W2hV3sHqeQceZrog5WGTsEjJd8GDI?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "拉薩市新能源汽車充電站蓮花公園站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdedQHcXbxxn7sUlAwPWb0BF-m4Q9kcprnbRIBAkiKLyDuJrRcBnFvSOEhHWerPp2jPHFgviV2M_yYep0DpaVXTVU7iafE5fwbn9ME_-qCzbtsK8ZCCCO4uXoQVZ7pL9OCFCV5ut0__df4V3PP4S2jDhrH70io?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "昆明高鐵南站充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXez4ifkQCOLHFz7FkOUMlzf5AWkCD_qx9l0dp7X8zZYe4ThXqzmRect_ECtiD1-vW3MNtYYPqq-iODv-W4sV6CMqaZjEA0xynkw3wlSDk7rIFPKMcib-AiFyIhir5VwhRXYMcYNoIXzywQ63mOz21LeMeGT2zo?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海寶山區江場西路1737充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcMVR3tW6VvZXMDHUWufcH3vbprVXdZFJPCzFtgoP1D2XytgLp9-cSC1x9AsrZygekA4qOZebaKJqZL24uL7p1gMpQ250_3UeKmojdIWWI-2vlNRGuzsj5S_wWau8Iln8f0tRTtHxbm0hBpT8zgM_MQVGnivA?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海馬陸超級充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcOPh18_4CjrZj380xm9AvAeHe01MOq1-6aYU7Se88kAXoCFSRwRMPJ6aLQUwBdTJCGM0lQEGCP6H7wX4yfqCF4F8Wc2zrD0ZJ0YAIsF7sv7JPJc37xnSKjIG6qSYGwZjkG59psVhS50-HP-NObdU5cEBLVxEw?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海經緯置業充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdQffa_uAtqvcCHtMVkQn1tyUVHPIWzozuKn_0XTxP8lC81-Gxdp6YbDxvzXz7fzHte9LXBxNhO54kFYcvNF76IIO-70KGfV04O7JtMeAQ95ayh6w17PeLHrkozrQevYwvWrjSNwIlqo746_s_iL1mANVJ5FT0?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "台州市天悅年華小區充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdfSHaEMGoHnbbeufFZRtKsbxhP3g53OV0SlvX5q4QRQkH8-NTs0WHiZbwQOlPCLbl_L_L_rhOxPkBhpEHaRdYyMG1TpenzYBt6_G57LcnSPr7XYgYtVJc6wGe_tP2d9tjtgfIYY1FnED1N_oeA1y0ft96xRtM?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海方舟苑小區": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdq0CUPtCnR8rVGYHr-JfGE_U3kME6QknyxsfJTw4ThofZQ7IEhhQdVhFh89x5EjeBQg5rFQwmDGSUu9j7GJkIivwL_iMXyxgowqdQioRmjD863T7AM8qLhDLr3Ud0rBUns7aorFffl46TP9zltH0eUwGakbHg?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "青島特銳德園區智能微網充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcXkMCDRX8BycnI6VQRYyagmonBpcyomwM-kL99A3otil-YSATeFl379S8dWlArsfraIwojcx9M1e9mMEYJqwV-1oEGd2j01--5CjhcDneq7wNKvsBcLzkN6ZF47AELWunt5DEB_eAq54SPzP3dJjQ_1UaB_vE?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "武漢京東亞洲1號充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXebTaXNG-Kt8KZg3WtjPxuXK9oVty4j1uDdI9SfjLm9MMZfIvL6EnAIhai0qo7d5shRabGAu9cX7Z9tyUfGHjj_AECVpVmsFnIIfBSgbysqixwfa9sTxjiSji32Tvlzqt57ZkSYQM5cHM4rmhhkSqwpMCMMdZc?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "安陽豐和物流充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXez7NoC7XRct5N3zjZdoZkiYfcX8oQPPbg5HnvaoywM3ZIJOYKOwdZjk0WJDSxWRh-4mhIL_VmdzEcMdb3YpSIcwymKeuBfpPmS_uRpdTeOKKTcfDEbiMCKd9NJRGAF42OfLRZFIwAFA8cGGxudWC2BDYnO8g?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "蒙能錫林浩特電廠重卡充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdwmS1G0zpPxiAI8JkRT8o0-ChHBfucapU28Zxhplk3d4wst5Lmke23TX7ScG1y73GAuH4Li5knzf_7lnEayj8-kgoKRlohCl4epR27_BqqlMhRQyEcf6O2qWTBgM7SvuJR8BhGIke8vss7J4_nu6f1XMlX38w?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "唐山縱橫鋼鐵充電項目": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfzozusJHJzt2k-_dfOeTo0El3Haw1_5WGZC4WbBn_uE8r9390ioONypC-bdk7MKB7JxLzqHhlFfG172IAhYn2G5p4SpE94GuGRpgiktnWbELo6O6g8f6sPVDw_tQffisybtPME8qQoJlajMfYHgqnOZ8vSDuU?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "廣西北部灣港": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXchrSIBEC-ajf9QjsVb5WhOucS6eKxYwrSJCz468uhvlYZ4QN9wZ3zRHyTbGXbp1uLjcPO6Hh8SQ2-SeDXRbRBaAiwAQZOgf0tvR_Mwl_LvPMftTSodYQ82fxo18usM4tybHCJ8M7QZ1vtyFwgocFoNOINA9Bw?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "寧波港碼頭項目": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdBc5fuDiDg1KKY1CNAErof-R7-wc_iCdm4i3gDN-giuxZWEoJ5CZ845KYc36KA0vgxTPP6w10I0DNn792d0mHxyZilawFfFs4szeYEFrTsPPYrWBrilaaFIKertPZAQh6-BDGvxaFoLqUmKHA8jKeGs-4lTw?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "成都天府國際機場充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfaTDACwOXZhWf3fMXNd9bHjvEEABkqaaFdg2PIvWacSZlooRRN1BwnwEl5FH_JIuIpemavi1gRnFQTGUuHNKeVxXcn8MhheDLnrwwN7RiD8BwoLOx7aQKxRx_RA3wEcNO9eRN2nwLYPgZIEYuR2VbF9sFNLg?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "杭州蕭山國際機場充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdPwx0mCNegUrd_RcaJ78g3SuPmDveLlUKJ29rZB1_nmsJpRN76CnX8IqIkMFCb11GQ7HV6-035Oj2IqYPSpYHVN-FNobkN4vAfzQ7Cbwi73YQoHrSbEt7Z1ETNx_MxTl1oBsJfhTxXsZSo-7-fLggo48XaIg?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "廣州白雲國際機場充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXelHbMVx09b_7hJSDIhwMybw0Xz-gRfj5-IAlhSw21xk-y6UBhczAP3MVmfhK3zN2AthMyhQFVvOu8Ht26-tLbz217UPRdfvF3H7w82j5r9ooLkegos7V0Vs_M5qwxT-ITt3QF2WZQ6wZ_Zrxth7E8XgrnbAdY?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海浦東國際機場": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdcfpW-HdKeeX3qOGx2ZYzqSXxibKKtfCtdBmWdFBCUBj0Buy6ARR33LlNOoycucVuQMlVeDagqPRDL6rWROGKHVrMCFK595WhqCICXJylDbjwVyewoORHfWNwmUeq0VI2Acv97cZDBb4G9ryaVIrrMeddvWlk?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "北京大興國際機場南航基地": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdtsMDPYRhgz9eEQrE7qSPnnUCE6ex4fe40pV3RMYW2yPTwy03rLD7zcHQ8aYGlgCQDsL-cgMlgS1_Mq6kkmEUXCf2f7-uZSPQrrS1RMI1x_eeB7lyhhs0RYCBE9nkAwsZczUeYajYMwYhwL9_KoGpYvqDbLkc?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "保定低碳公園智慧車棚": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXforw6RXcq6TLVY-n49fmS5jl5I43ln0xdiKkGnoly4gAtxiLKk7xgC9u8A13-XFVoin942yL5QG2p2_IHLZbJ-bK26jCGepbBX9VBwQYRg0w4kTIBuQUu2txVEddQNAxG-6qkgfcgCXnk7fOcbr9_11fUFRRU?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "深圳國際低碳城光儲充放一體化項目": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXeOd_Fg2EX8PD4LPw9CmaIXhQHJTFVzGAWqE7eUy3lGly98-gZHtmyxTc1LtjZoUvbytsMEPUMq06dlvFrPXwLHz9gkIVeKXeEfvM5BxCFZjT0Hl-Nuqa_Vuur2yRbSdXBRESqBDiPfcwM-LKgFnh6t2WmSL4E?key=7ewXKUOIU8nU-qIj2J_ImQ",
  "上海基金小鎮智慧車棚": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcxeV2c7Mnsbns1o1zCAl4gE1pEHt8OvvkvhEPYJV4Zv6vNY5tU--crAIndy8vb_cgGWLJ4ZqyzM1ljyMhGHJqXRRNJ9raNPU_0Bhz0pgeB4Si1nd9IFFv2fbhIowKYrmOCq6VDWX8tjSDvsk1ceLqklTHMjGA?key=7ewXKUOIU8nU-qIj2J_ImQ"
};

for (const [title, imageUrl] of Object.entries(imageUpdates)) {
  const regex = new RegExp(`(title:\\s*"${title}",[\\s\\S]*?image:\\s*")[^"]*(",)`);
  content = content.replace(regex, `$1${imageUrl}$2`);
}

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
