const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

const domesticCasesRegex = /const domesticCases: CaseDetail\[\] = \[([\s\S]*?)\];\n\n  const internationalCases/;
const match = content.match(domesticCasesRegex);

if (!match) {
  console.error("Could not find domesticCases array");
  process.exit(1);
}

let domesticCasesStr = match[1];

// Replace cases with category: "地產"
const caseRegex = /\{\s*title:\s*"([^"]+)"[\s\S]*?details:\s*\{[\s\S]*?\}\s*\}/g;

let newDomesticCasesStr = domesticCasesStr.replace(caseRegex, (match, title) => {
  if (match.includes('category: "地產"')) {
    return "DELETE_ME";
  }
  return match;
});

newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME,\s*/g, '');
newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME/g, '');

const newCases = `,
    {
      title: "上海經緯置業充電站",
      location: "上海市",
      desc: "為大型住宅社區提供便捷的公共充電服務，滿足社區居民日常充電需求，有效緩解小區充電難題。",
      tags: ["住宅社區", "便民服務", "地產配套"],
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=80&w=2072&auto=format&fit=crop",
      category: "地產",
      details: {
        chargingPiles: "終端數量 140個",
        energySaving: "推動社區綠色出行",
        feedback: "極大方便了小區居民的新能源車充電需求。"
      }
    },
    {
      title: "台州市天悅年華小區充電站",
      location: "浙江省台州市",
      desc: "為天悅年華小區居民提供專屬的充電基礎設施，提升小區物業服務品質與居民生活便利性。",
      tags: ["小區充電", "物業服務", "綠色社區"],
      image: "https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?q=80&w=2071&auto=format&fit=crop",
      category: "地產",
      details: {
        chargingPiles: "終端數量 36個",
        energySaving: "完善社區新能源配套",
        feedback: "充電設施安全可靠，居民使用滿意度高。"
      }
    },
    {
      title: "青島特銳德園區智能微網充電站",
      location: "山東省青島市",
      desc: "特銳德園區內的智能微網充電示範項目，集成了群充、特惠充及V2G系統，打造企業園區綠色微電網標杆。",
      tags: ["智能微網", "V2G系統", "企業園區"],
      image: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=2074&auto=format&fit=crop",
      category: "地產",
      details: {
        chargingPiles: "終端數量 2組群充系統、2組特惠充、1組V2G系統，共28個終端",
        energySaving: "實現園區能源智能調度與高效利用",
        feedback: "微網系統運行穩定，展現了強大的技術實力。"
      }
    },
    {
      title: "上海方舟苑小區",
      location: "上海市",
      desc: "針對小區引入的充電設施項目，解決了方舟苑小區居民的充電痛點，助力小區綠色升級。",
      tags: ["住宅小區", "社區改造", "便民充電"],
      image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=2069&auto=format&fit=crop",
      category: "地產",
      details: {
        chargingPiles: "終端數量 7個",
        energySaving: "促進小區新能源汽車普及",
        feedback: "切實解決了居民的燃眉之急。"
      }
    }`;

newDomesticCasesStr = newDomesticCasesStr.trim();
if (newDomesticCasesStr.endsWith(',')) {
    newDomesticCasesStr = newDomesticCasesStr.slice(0, -1);
}
newDomesticCasesStr += newCases;

content = content.replace(domesticCasesStr, newDomesticCasesStr + '\n  ');

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
