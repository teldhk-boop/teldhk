const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

const updates = {
  "上海11路/26路公交智能充電站": "終端數量 12槍+12弓",
  "上海奉賢公交南橋充電站": "終端數量 5弓+10槍",
  "上海強生漕寶停車場生態復用站": "終端數量 40個",
  "四川省九寨溝自然保護區充電站": "終端數量 85個",
  "成都公交充電網": "終端數量 5800個",
  "深圳特來電國際會展中心充電站": "終端數量 188個",
  "昆明高鐵南站充電站": "終端數量 53個",
  "上海寶山區江場西路1737充電站": "終端數量 96個",
  "拉薩市新能源汽車充電站蓮花公園站": "終端數量 16個",
  "上海馬陸超級充電站": "終端數量 103個"
};

for (const [title, chargingPiles] of Object.entries(updates)) {
  const regex = new RegExp(`(title:\\s*"${title}",[\\s\\S]*?chargingPiles:\\s*")[^"]*(",)`);
  content = content.replace(regex, `$1${chargingPiles}$2`);
}

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
