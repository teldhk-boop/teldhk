const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

const toRemove = [
  "重慶交運光亮城公交充電站",
  "上海寶山地下出租車專用充電站",
  "畢節市公交高家龍灘充電站",
  "貴州安順城市公交充電網"
];

for (const title of toRemove) {
  const regex = new RegExp(`\\s*\\{\\s*title:\\s*"${title}"[\\s\\S]*?details:\\s*\\{[\\s\\S]*?\\}\\s*\\},?`, 'g');
  content = content.replace(regex, '');
}

const newCases = `    {
      title: "上海強生漕寶停車場生態復用站",
      location: "上海市",
      desc: "結合停車場空間進行生態復用，為出租車及社會車輛提供高效的充電服務，實現土地資源的最大化利用與綠色升級。",
      tags: ["生態復用", "停車場", "資源利用"],
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=80&w=2072&auto=format&fit=crop",
      category: "公共交通",
      details: {
        chargingPiles: "多台直流快充終端",
        energySaving: "提高土地資源利用率，助力城市節能減排",
        feedback: "極大緩解了市區充電難題，場站環境優美。"
      }
    },
    {
      title: "四川省九寨溝自然保護區充電站",
      location: "四川省阿壩州",
      desc: "位於世界自然遺產九寨溝景區，為景區環保車輛及遊客新能源車提供綠色能源補給，保護脆弱的生態環境。",
      tags: ["自然保護區", "綠色旅遊", "生態保護"],
      image: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=2074&auto=format&fit=crop",
      category: "公共快充站",
      details: {
        chargingPiles: "環保型直流快充終端",
        energySaving: "助力景區實現零排放目標",
        feedback: "設備與自然環境和諧共存，運行穩定可靠。"
      }
    },
    {
      title: "成都公交充電網",
      location: "四川省成都市",
      desc: "構建覆蓋成都市區的公交充電網絡，實現公交車輛的智能化調度和高效充電，全面助力成都公交電動化。",
      tags: ["城市充電網", "公交電動化", "智能調度"],
      image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=2069&auto=format&fit=crop",
      category: "公共交通",
      details: {
        chargingPiles: "分佈式公交專用充電網絡",
        energySaving: "全面提升城市公共交通能效",
        feedback: "充電網絡佈局完善，極大提升了公交運營效率。"
      }
    }`;

content = content.replace(/(  ];\n\n  const internationalCases)/, newCases + '\n$1');

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
