const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

const domesticCasesRegex = /const domesticCases: CaseDetail\[\] = \[([\s\S]*?)\];\n\n  const internationalCases/;
const match = content.match(domesticCasesRegex);

if (!match) {
  console.error("Could not find domesticCases array");
  process.exit(1);
}

let domesticCasesStr = match[1];

// Helper to replace/delete cases
const caseRegex = /\{\s*title:\s*"([^"]+)"[\s\S]*?details:\s*\{[\s\S]*?\}\s*\}/g;

let newDomesticCasesStr = domesticCasesStr.replace(caseRegex, (match, title) => {
  // 1. 地產: Delete "青島特銳德園區智能微網充電站"
  if (title === "青島特銳德園區智能微網充電站") {
    return "DELETE_ME";
  }

  // 2. 物流: Delete all except "武漢京東亞洲1號充電站"
  if (match.includes('category: "物流"')) {
    if (title === "武漢京東亞洲1號充電站") {
      return match.replace(/chargingPiles:\s*"[^"]*"/, 'chargingPiles: "終端數量 63個"');
    } else {
      return "DELETE_ME";
    }
  }

  // 3. 空港: Delete "寶馬機場尊享服務區充電站", "重慶江北國際機場充電站"
  if (match.includes('category: "空港"')) {
    if (title === "寶馬機場尊享服務區充電站" || title === "重慶江北國際機場充電站") {
      return "DELETE_ME";
    }
    if (title === "成都天府國際機場充電站") {
      return match.replace(/chargingPiles:\s*"[^"]*"/, 'chargingPiles: "終端數量 639個"');
    }
    if (title === "廣州白雲國際機場充電站") {
      return match.replace(/chargingPiles:\s*"[^"]*"/, 'chargingPiles: "終端數量 88個"');
    }
    if (title === "杭州蕭山國際機場充電站") {
      return match.replace(/chargingPiles:\s*"[^"]*"/, 'chargingPiles: "終端數量 52個"');
    }
  }

  return match;
});

// Clean up DELETE_ME
newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME,\s*/g, '');
newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME/g, '');

// Add new cases
const newCases = `,
    {
      title: "安陽豐和物流充電站",
      location: "河南省安陽市",
      desc: "為安陽豐和物流園區提供高效的充電服務，滿足物流車輛高頻次、大功率的充電需求。",
      tags: ["物流園區", "高效充電", "物流車隊"],
      image: "https://images.unsplash.com/photo-1586191582119-2925c69c6ade?q=80&w=2070&auto=format&fit=crop",
      category: "物流",
      details: {
        chargingPiles: "終端數量 20個",
        energySaving: "降低物流運輸成本，推動綠色物流",
        feedback: "充電速度快，設備運行穩定。"
      }
    },
    {
      title: "蒙能錫林浩特電廠重卡充電站",
      location: "內蒙古錫林郭勒盟",
      desc: "為蒙能錫林浩特電廠的重卡運輸車隊提供專屬充電服務，助力重工業綠色物流轉型。",
      tags: ["重卡充電", "電廠配套", "綠色物流"],
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=2070&auto=format&fit=crop",
      category: "物流",
      details: {
        chargingPiles: "終端數量 8個",
        energySaving: "大幅減少重卡碳排放",
        feedback: "適應高寒氣候，保障重卡高效運轉。"
      }
    },
    {
      title: "唐山縱橫鋼鐵充電項目",
      location: "河北省唐山市",
      desc: "為唐山縱橫鋼鐵廠區內的運輸車輛提供充電解決方案，推動鋼鐵行業低碳發展。",
      tags: ["鋼鐵廠區", "運輸車輛", "低碳發展"],
      image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop",
      category: "物流",
      details: {
        chargingPiles: "終端數量 雙槍單樁10台",
        energySaving: "助力鋼鐵企業實現綠色轉型",
        feedback: "設備耐用，完全適應廠區惡劣環境。"
      }
    },
    {
      title: "廣西北部灣港",
      location: "廣西壯族自治區",
      desc: "在廣西北部灣港口部署自動化充電系統，為港口物流車輛及設備提供智能、高效的能源補給。",
      tags: ["港口碼頭", "自動化充電", "智能補給"],
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=80&w=2072&auto=format&fit=crop",
      category: "物流",
      details: {
        chargingPiles: "終端數量 6套SCD自動充電系統",
        energySaving: "推動港口物流電氣化與智能化",
        feedback: "自動化程度高，大幅提升港口運營效率。"
      }
    },
    {
      title: "寧波港碼頭項目",
      location: "浙江省寧波市",
      desc: "為寧波港碼頭的集裝箱卡車及物流車輛提供大規模充電服務，助力打造綠色智慧港口。",
      tags: ["寧波港", "集卡充電", "智慧港口"],
      image: "https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?q=80&w=2071&auto=format&fit=crop",
      category: "物流",
      details: {
        chargingPiles: "終端數量 96個",
        energySaving: "顯著降低港口物流碳排放",
        feedback: "充電設施規模大，滿足港口高強度作業需求。"
      }
    },
    {
      title: "上海浦東國際機場",
      location: "上海市",
      desc: "為上海浦東國際機場提供全面的充電基礎設施，涵蓋旅客停車場及機場特種車輛充電需求。",
      tags: ["浦東機場", "全面覆蓋", "特種車輛"],
      image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=2069&auto=format&fit=crop",
      category: "空港",
      details: {
        chargingPiles: "終端數量 52個",
        energySaving: "打造綠色航空樞紐",
        feedback: "極大滿足了機場複雜多樣的充電需求。"
      }
    },
    {
      title: "北京大興國際機場南航基地",
      location: "北京市",
      desc: "為北京大興國際機場南航基地的航空物流及工作車輛提供高效的充電服務，保障機場運營。",
      tags: ["大興機場", "南航基地", "航空物流"],
      image: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=2074&auto=format&fit=crop",
      category: "空港",
      details: {
        chargingPiles: "終端數量 71個",
        energySaving: "支持現代化機場的綠色運營",
        feedback: "充電設施完善，服務體驗極佳。"
      }
    }`;

newDomesticCasesStr = newDomesticCasesStr.trim();
if (newDomesticCasesStr.endsWith(',')) {
    newDomesticCasesStr = newDomesticCasesStr.slice(0, -1);
}
newDomesticCasesStr += newCases;

content = content.replace(domesticCasesStr, newDomesticCasesStr + '\n  ');

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
