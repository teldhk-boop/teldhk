const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

// 1. Extract all domestic cases
const domesticCasesRegex = /const domesticCases: CaseDetail\[\] = \[([\s\S]*?)\];\n\n  const internationalCases/;
const match = content.match(domesticCasesRegex);

if (!match) {
  console.error("Could not find domesticCases array");
  process.exit(1);
}

let domesticCasesStr = match[1];

// We need to parse this string or use regex to remove cases with category: "公共快充站"
// except the two allowed ones.
// A safer way is to split the cases by `    },\n    {` or similar, but regex is easier if we are careful.

// Let's use a replacer function to process each case block
const caseRegex = /\{\s*title:\s*"([^"]+)"[\s\S]*?details:\s*\{[\s\S]*?\}\s*\}/g;

let newDomesticCasesStr = domesticCasesStr.replace(caseRegex, (match, title) => {
  const isPublicFastCharge = match.includes('category: "公共快充站"');
  
  if (isPublicFastCharge) {
    if (title === "深圳特來電國際會展中心充電站") {
      return match.replace(/chargingPiles:\s*"[^"]*"/, 'chargingPiles: "終端數量 188個"');
    } else if (title === "拉薩市新能源汽車充電站蓮花公園站") {
      return match.replace(/chargingPiles:\s*"[^"]*"/, 'chargingPiles: "16個"');
    } else {
      // Remove this case by returning a special token or empty string
      return "DELETE_ME";
    }
  }
  
  return match;
});

// Clean up the deleted cases and their trailing commas
newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME,\s*/g, '');
newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME/g, '');

// Add the new cases
const newCases = `,
    {
      title: "昆明高鐵南站充電站",
      location: "雲南省昆明市",
      desc: "位於昆明高鐵南站的大型公共快充站，為高鐵旅客及周邊居民提供便捷的充電服務，助力綠色出行。",
      tags: ["高鐵樞紐", "公共快充", "綠色出行"],
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=80&w=2072&auto=format&fit=crop",
      category: "公共快充站",
      details: {
        chargingPiles: "53個",
        energySaving: "有效提升高鐵樞紐的綠色配套服務能力",
        feedback: "充電速度快，極大方便了高鐵換乘旅客。"
      }
    },
    {
      title: "上海寶山區江場西路1737充電站",
      location: "上海市寶山區",
      desc: "位於上海市寶山區的公共快充站，為周邊社區及商圈提供高效的充電網絡覆蓋。",
      tags: ["城市快充", "社區覆蓋", "高效網絡"],
      image: "https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?q=80&w=2071&auto=format&fit=crop",
      category: "公共快充站",
      details: {
        chargingPiles: "96個",
        energySaving: "推動城市綠色交通發展，降低碳排放",
        feedback: "終端數量多，充電無需排隊，體驗極佳。"
      }
    },
    {
      title: "上海馬陸超級充電站",
      location: "上海市嘉定區",
      desc: "上海馬陸超級充電站，配備大批量快充終端，為城市物流及私家車提供強大的能源補給支持。",
      tags: ["超級充電站", "大批量終端", "能源補給"],
      image: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=2074&auto=format&fit=crop",
      category: "公共快充站",
      details: {
        chargingPiles: "103個",
        energySaving: "顯著提升區域新能源車輛的運營效率",
        feedback: "場站規模大，充電效率高，服務設施完善。"
      }
    }`;

// Append new cases to the end of domesticCases array
newDomesticCasesStr = newDomesticCasesStr.trim();
if (newDomesticCasesStr.endsWith(',')) {
    newDomesticCasesStr = newDomesticCasesStr.slice(0, -1);
}
newDomesticCasesStr += newCases;

content = content.replace(domesticCasesStr, newDomesticCasesStr + '\n  ');

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
