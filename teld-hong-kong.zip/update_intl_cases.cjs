const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

const imageMap = {
  "馬來西亞公共充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfGW3uqcPbjKpHuS_sAbFFa70wGcY0lwVFSjQuumaRAROMMLitHGL2Ld5O3cGJDmdqM3T64m_28uJo62DIiGyOWuGjAfQ5mx63M8KjQXoh4l7aH6p7NQsdREwwM2lzqoKxUU1QF?key=SIyLmeyd_R4-mtm9cVIzJA",
  "英國倫敦巴士充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXc21PMziKytjrtmOS1pNPv5V3gx5UlEeAxCXlUu9efXWswHmUf1OYPv74Ee-GFeqaO0g8l93kbg0bWzbsghTwpZ1hGo4pLNpMHXe5DmeImcComjVUSfF9-mLWmZZWpwiFziBcz2?key=SIyLmeyd_R4-mtm9cVIzJA",
  "哈薩克斯坦公共充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXf9OVCkeeVn39uVX74rGaDv2BCCPHCq56LVpzwMw_WpAK8UZdOETiqjeo8eGp76Mennd00JprcGad7549xEFESw4CaNyno9Hqtv4oyAKF_LMaL7sWMZzai14Sh8pQnBWNzkpMmoOQ?key=SIyLmeyd_R4-mtm9cVIzJA",
  "澳大利亞礦山項目": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXestGoJe_2_qUpfwYhPl78XVURZE_n0sV40bLA6TLbHylMchp-Lj5yBqJB6Phbm-QgSB6Y5BW5oSv_H0WuJId6PdbsazVOMqILh4c5hGsmznHkPR-FRfUi_VpyqVA6dFTgefsCKqw?key=SIyLmeyd_R4-mtm9cVIzJA",
  "德國寶馬總部實驗室設備": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdqYoklehHXNTatweCKDSprnB2wCG8w53FCxcg0p8swqY8GTuJQkyrJRrBeXmK7loFFfWPnCIlgaHGmQJPSAUhxNwyA2kk3ZaN218AdmXXxio0-qyl4vgL6h1OxEfUtJrKDE_IU?key=SIyLmeyd_R4-mtm9cVIzJA",
  "中車新西蘭巴士項目": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdLiGzMrqNKYJidd31oDGpXvMcwwvc9MDtvcgE1KrjseT4zSWvnTeKS64KxNcmM3KF4Sc-3rM8toZbzF8Wil73ghw1pY_RWzpklmH8JuRqs7bnWaoPVpMyTVMgznXkJQwrNhey0YA?key=SIyLmeyd_R4-mtm9cVIzJA",
  "卡塔爾公交充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXeC2qKO6cob-44QK2pcnki0DG81MDxt0fD4BDbONYqKKeAqmeRtQUufrI5tDhN_GzKRRZlUKec0BCMAVB9dH3x_Cc4lpkJk8azll1GBc8X04tXkGVDoJOVtZ9oz3rtB7uaWZrq_?key=SIyLmeyd_R4-mtm9cVIzJA",
  "俄羅斯公共充電站": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfcppXj8hk0mQNFGiE9uy5nra_il10I5Jg8O-e6aqDBVLeGIIaSF1cOGTMIPFJae_VCd7hTuBpX-vl4umCNQGWyCicbjZki6QxnDTHBbwdhDqhGUtQ_su0Bg7NZmdt1pHieqvWKzQ?key=SIyLmeyd_R4-mtm9cVIzJA",
  "烏茲別克斯坦項目": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXe5GpE2ql7Awbm_kRYzBbRlre4k1S8sx7JQLBmKV0vbw5FZE6CmUUbGnoNdtYwqM5jFzxFo6MTcRQvUT_hjPO3hMJFAn3XaPrukvYcq-skmn9l0-aMJNvoSRHjOed7NeWMvZW47Hg?key=SIyLmeyd_R4-mtm9cVIzJA",
  "厄瓜多爾項目": "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdgspcTCTnMwvtErWB11Jj-bCLgvVsgv9bUaE63L8KmZPvGtM6hJZZor5yQOYGOy86qmDWS3Tz71WRsP7FgSni69Y5gNtQjr-I0giM2dQaDxhdQXSZYMOAyvX-nXIGWzvXfQb_r5w?key=SIyLmeyd_R4-mtm9cVIzJA"
};

for (const [title, image] of Object.entries(imageMap)) {
  const regex = new RegExp(`(title:\\s*"${title}",[\\s\\S]*?image:\\s*")[^"]*(",)`);
  content = content.replace(regex, `$1${image}$2`);
}

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
