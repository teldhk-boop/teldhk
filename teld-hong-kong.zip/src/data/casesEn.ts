import { CaseDetail, PartnerCategory } from './types';

export const domesticCasesEn: CaseDetail[] = [
  {
    title: "Shenzhen TELD International Convention and Exhibition Center Charging Station",
    location: "Shenzhen, Guangdong",
    desc: "Located in the Shenzhen International Convention and Exhibition Center, it provides large-scale and high-efficiency public charging network services for exhibitors and the public, demonstrating TELD's strong station operation capabilities.",
    tags: ["Public Charging Network", "Convention Center", "Large-scale Station"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcpPK3WQK6qMcouv8CNQAQIwP946L9T_9RuOMItzmw-2pQjebSDkbhkBcBb3iRAM9of5qA8CBN_9YceVwdPvvFhdnJhooFBIpoxYtUAtmeWDGCK1CYKNCV73Pmbukemr2W2hV3sHqeQceZrog5WGTsEjJd8GDI?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Fast Charging Station",
    details: {
      chargingPiles: "Number of terminals: 188",
      energySaving: "Ensures high-frequency charging needs during large exhibitions",
      feedback: "Fast charging speed, sufficient parking spaces, excellent service experience."
    }
  },
  {
    title: "Chengdu Tianfu International Airport Charging Station",
    location: "Chengdu, Sichuan",
    desc: "Provides charging services for aviation logistics and passenger vehicles at Chengdu Tianfu International Airport, ensuring the efficient operation of new energy vehicles at the airport.",
    tags: ["Aviation Logistics", "Airport Facilities", "Efficient Operation"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfaTDACwOXZhWf3fMXNd9bHjvEEABkqaaFdg2PIvWacSZlooRRN1BwnwEl5FH_JIuIpemavi1gRnFQTGUuHNKeVxXcn8MhheDLnrwwN7RiD8BwoLOx7aQKxRx_RA3wEcNO9eRN2nwLYPgZIEYuR2VbF9sFNLg?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Airport",
    details: {
      chargingPiles: "Number of terminals: 639",
      energySaving: "Promotes the construction of green airports and reduces ground carbon emissions",
      feedback: "Perfectly adapts to the high-intensity operation rhythm of the airport."
    }
  },
  {
    title: "Lhasa New Energy Vehicle Charging Station Lotus Park Station",
    location: "Lhasa, Tibet Autonomous Region",
    desc: "A public charging station built in high-altitude areas, overcoming the challenges of plateau climate, providing stable energy supply for new energy vehicles in Lhasa.",
    tags: ["High Altitude", "Public Charging", "Plateau Climate"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdedQHcXbxxn7sUlAwPWb0BF-m4Q9kcprnbRIBAkiKLyDuJrRcBnFvSOEhHWerPp2jPHFgviV2M_yYep0DpaVXTVU7iafE5fwbn9ME_-qCzbtsK8ZCCCO4uXoQVZ7pL9OCFCV5ut0__df4V3PP4S2jDhrH70io?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Fast Charging Station",
    details: {
      chargingPiles: "Number of terminals: 16",
      energySaving: "Protects the ecological environment of the snow-covered plateau",
      feedback: "The equipment still maintains high efficiency and stability in hypoxic and low-temperature environments."
    }
  },
  {
    title: "Shanghai Route 11/26 Bus Smart Charging Station",
    location: "Shanghai",
    desc: "Provides exclusive charging services for core bus routes in downtown Shanghai, adopting a smart dispatching system to ensure the efficient operation of buses.",
    tags: ["Bus Exclusive", "Smart Dispatching", "Core Routes"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdqrbTn5QoJNAoZT4grjUvxEy4W0ztyt5okJQZuGZQU61EYrxH_uRIi74jxcb_RPcHxtlfjgQGr7JOreAjvFTJJzjsnKUdYPTdxP1D5HjIaWtvuNxZ_V5onnVMWsR7fwctmi0Ga_SsLAyf_YXyBlhjLEr16gbg?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Transportation",
    details: {
      chargingPiles: "Number of terminals: 12 guns + 12 bows",
      energySaving: "Ensures zero-emission operation of urban public transportation",
      feedback: "The smart dispatching system significantly improves charging efficiency."
    }
  },
  {
    title: "Shanghai Fengxian Bus Nanqiao Charging Station",
    location: "Fengxian District, Shanghai",
    desc: "An important bus charging hub in Fengxian District, supporting the daily charging and maintenance of large-scale bus fleets, and is the basic guarantee for regional green transportation.",
    tags: ["Bus Hub", "Large-scale Fleet", "Green Transportation"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcw9SLdudTUbWiQc5lkvRuqIIp331bihEooJPYvHMM2zAlYmeOhD19yFsg4tzl94-whRqxFH4kG8eaCa-QlpBjeHWKhCaJFavoRgaRNxepwb5RaknwEQ-2a780-GJmb9ypdIeG5RihSIlWj66uj8GN0YcwapnY?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Transportation",
    details: {
      chargingPiles: "Number of terminals: 5 bows + 10 guns",
      energySaving: "Reduces bus operating costs",
      feedback: "Stable and reliable equipment, meeting the high-intensity operation needs of the fleet."
    }
  },
  {
    title: "Wuhan JD Asia No.1 Charging Station",
    location: "Wuhan, Hubei",
    desc: "Provides large-scale logistics vehicle charging solutions for JD Logistics Asia No.1 Park, ensuring the efficient operation of a huge logistics fleet.",
    tags: ["JD Logistics", "Large Park", "Efficient Operation"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXebTaXNG-Kt8KZg3WtjPxuXK9oVty4j1uDdI9SfjLm9MMZfIvL6EnAIhai0qo7d5shRabGAu9cX7Z9tyUfGHjj_AECVpVmsFnIIfBSgbysqixwfa9sTxjiSji32Tvlzqt57ZkSYQM5cHM4rmhhkSqwpMCMMdZc?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Logistics",
    details: {
      chargingPiles: "Number of terminals: 63",
      energySaving: "Significantly reduces the operating costs of the logistics park",
      feedback: "High charging efficiency, perfectly supporting the high-intensity logistics operations of the park."
    }
  },
  {
    title: "Hangzhou Xiaoshan International Airport Charging Station",
    location: "Hangzhou, Zhejiang",
    desc: "Provides comprehensive charging services for Hangzhou Xiaoshan International Airport, covering passenger parking lots and internal special vehicle charging needs.",
    tags: ["International Airport", "Comprehensive Coverage", "Special Vehicles"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdPwx0mCNegUrd_RcaJ78g3SuPmDveLlUKJ29rZB1_nmsJpRN76CnX8IqIkMFCb11GQ7HV6-035Oj2IqYPSpYHVN-FNobkN4vAfzQ7Cbwi73YQoHrSbEt7Z1ETNx_MxTl1oBsJfhTxXsZSo-7-fLggo48XaIg?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Airport",
    details: {
      chargingPiles: "Number of terminals: 52",
      energySaving: "Building a green aviation hub",
      feedback: "Greatly meets the complex and diverse charging needs of the airport."
    }
  },
  {
    title: "Guangzhou Baiyun International Airport Charging Station",
    location: "Guangzhou, Guangdong",
    desc: "A large charging hub built at Guangzhou Baiyun International Airport, providing efficient energy supply for passengers, ride-hailing cars, and airport work vehicles.",
    tags: ["Large Hub", "Baiyun Airport", "Efficient Supply"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXelHbMVx09b_7hJSDIhwMybw0Xz-gRfj5-IAlhSw21xk-y6UBhczAP3MVmfhK3zN2AthMyhQFVvOu8Ht26-tLbz217UPRdfvF3H7w82j5r9ooLkegos7V0Vs_M5qwxT-ITt3QF2WZQ6wZ_Zrxth7E8XgrnbAdY?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Airport",
    details: {
      chargingPiles: "Number of terminals: 88",
      energySaving: "Supports the green operation of the largest aviation hub in South China",
      feedback: "Perfect charging facilities, greatly facilitating airport travel."
    }
  },
  {
    title: "Shanghai Qiangsheng Caobao Parking Lot Ecological Reuse Station",
    location: "Shanghai",
    desc: "Combines parking lot space for ecological reuse, equipped with multiple DC fast charging terminals, providing efficient charging services for taxis and social vehicles, achieving maximum utilization of land resources and green upgrades.",
    tags: ["Ecological Reuse", "Parking Lot", "Resource Utilization"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXd6xfBhDApVtabzF8UiBQN_zSBxVQMRQF2zm89ulzxSxRJIkx78P6E_CT9FVyTmCMbkkXlCNfDDe5pIi1WVZ8enFEhYYMtTbCi6fGukIFbvzSiozm1W1fX8yO1eCLs2Wk3k469iigygKJL-YsxFbJzW1skkWiU?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Transportation",
    details: {
      chargingPiles: "Number of terminals: 40",
      energySaving: "Improves land resource utilization and helps urban energy conservation and emission reduction",
      feedback: "Greatly alleviates the difficulty of charging in urban areas, with a beautiful station environment."
    }
  },
  {
    title: "Sichuan Jiuzhaigou Nature Reserve Charging Station",
    location: "Aba Prefecture, Sichuan",
    desc: "Located in the World Natural Heritage Jiuzhaigou Scenic Area, equipped with environmentally friendly DC fast charging terminals, providing green energy supply for scenic environmental protection vehicles and tourists' new energy vehicles, protecting the fragile ecological environment.",
    tags: ["Nature Reserve", "Green Tourism", "Ecological Protection"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdFRw1C5Zbdb5I9OvoIHtgQ7-LU1JAPwUeq0__c6xr-Kcd457q4T156rQVNX5Sha4N5JTWl0SDjg-Kwzr2376JQf_OaIeC1lEgaBrb7YeMOo9Pb5RYpOvEIrIy8iF3KHL_Z1MPZ1aNN4Z2gYm0ihQfrBs0SmIY?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Transportation",
    details: {
      chargingPiles: "Number of terminals: 85",
      energySaving: "Helps the scenic area achieve zero-emission goals",
      feedback: "The equipment coexists harmoniously with the natural environment and operates stably and reliably."
    }
  },
  {
    title: "Chengdu Bus Charging Network",
    location: "Chengdu, Sichuan",
    desc: "Builds a bus charging network covering the urban area of Chengdu, configures a distributed bus-specific charging network, realizes intelligent dispatching and efficient charging of buses, and fully supports the electrification of Chengdu buses.",
    tags: ["Urban Charging Network", "Bus Electrification", "Smart Dispatching"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfSTZmVI4ppDbBi1PQbVUzN18-mo36cQ8jvwdq-64oo85une7KvxgFCzopONfX9sTNqYAyxSMkVdGRwSLBAiQQxboR4vc-u8eZ5F-rRutRLDuWVPSHnEdRx4xi6kpPif2SpamT312xkKZdRHsJu0vSaY59Egjk?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Transportation",
    details: {
      chargingPiles: "Number of terminals: 5800",
      energySaving: "Comprehensively improves the energy efficiency of urban public transportation",
      feedback: "Perfect charging network layout, greatly improving bus operation efficiency."
    }
  },
  {
    title: "Kunming High-speed Railway South Station Charging Station",
    location: "Kunming, Yunnan",
    desc: "A large public fast charging station located at Kunming High-speed Railway South Station, providing convenient charging services for high-speed railway passengers and surrounding residents, helping green travel.",
    tags: ["High-speed Rail Hub", "Public Fast Charging", "Green Travel"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXez4ifkQCOLHFz7FkOUMlzf5AWkCD_qx9l0dp7X8zZYe4ThXqzmRect_ECtiD1-vW3MNtYYPqq-iODv-W4sV6CMqaZjEA0xynkw3wlSDk7rIFPKMcib-AiFyIhir5VwhRXYMcYNoIXzywQ63mOz21LeMeGT2zo?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Fast Charging Station",
    details: {
      chargingPiles: "Number of terminals: 53",
      energySaving: "Effectively improves the green supporting service capabilities of high-speed rail hubs",
      feedback: "Fast charging speed, greatly convenient for high-speed rail transfer passengers."
    }
  },
  {
    title: "Shanghai Baoshan District Jiangchang West Road 1737 Charging Station",
    location: "Baoshan District, Shanghai",
    desc: "A public fast charging station located in Baoshan District, Shanghai, providing efficient charging network coverage for surrounding communities and business districts.",
    tags: ["Urban Fast Charging", "Community Coverage", "Efficient Network"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcMVR3tW6VvZXMDHUWufcH3vbprVXdZFJPCzFtgoP1D2XytgLp9-cSC1x9AsrZygekA4qOZebaKJqZL24uL7p1gMpQ250_3UeKmojdIWWI-2vlNRGuzsj5S_wWau8Iln8f0tRTtHxbm0hBpT8zgM_MQVGnivA?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Fast Charging Station",
    details: {
      chargingPiles: "Number of terminals: 96",
      energySaving: "Promotes the development of urban green transportation and reduces carbon emissions",
      feedback: "Many terminals, no queuing for charging, excellent experience."
    }
  },
  {
    title: "Shanghai Malu Super Charging Station",
    location: "Jiading District, Shanghai",
    desc: "Shanghai Malu Super Charging Station, equipped with a large number of fast charging terminals, provides strong energy supply support for urban logistics and private cars.",
    tags: ["Super Charging Station", "Mass Terminals", "Energy Supply"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcOPh18_4CjrZj380xm9AvAeHe01MOq1-6aYU7Se88kAXoCFSRwRMPJ6aLQUwBdTJCGM0lQEGCP6H7wX4yfqCF4F8Wc2zrD0ZJ0YAIsF7sv7JPJc37xnSKjIG6qSYGwZjkG59psVhS50-HP-NObdU5cEBLVxEw?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Fast Charging Station",
    details: {
      chargingPiles: "Number of terminals: 103",
      energySaving: "Significantly improves the operating efficiency of regional new energy vehicles",
      feedback: "Large station scale, high charging efficiency, perfect service facilities."
    }
  },
  {
    title: "Shanghai Jingwei Real Estate Charging Station",
    location: "Shanghai",
    desc: "Provides convenient public charging services for large residential communities, meets the daily charging needs of community residents, and effectively alleviates the difficulty of charging in communities.",
    tags: ["Residential Community", "Convenient Service", "Real Estate Facilities"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdQffa_uAtqvcCHtMVkQn1tyUVHPIWzozuKn_0XTxP8lC81-Gxdp6YbDxvzXz7fzHte9LXBxNhO54kFYcvNF76IIO-70KGfV04O7JtMeAQ95ayh6w17PeLHrkozrQevYwvWrjSNwIlqo746_s_iL1mANVJ5FT0?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Real Estate",
    details: {
      chargingPiles: "Number of terminals: 140",
      energySaving: "Promotes green travel in the community",
      feedback: "Greatly facilitates the charging needs of new energy vehicles for community residents."
    }
  },
  {
    title: "Taizhou Tianyue Nianhua Community Charging Station",
    location: "Taizhou, Zhejiang",
    desc: "Provides exclusive charging infrastructure for residents of Tianyue Nianhua Community, improving community property service quality and residents' living convenience.",
    tags: ["Community Charging", "Property Service", "Green Community"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdfSHaEMGoHnbbeufFZRtKsbxhP3g53OV0SlvX5q4QRQkH8-NTs0WHiZbwQOlPCLbl_L_L_rhOxPkBhpEHaRdYyMG1TpenzYBt6_G57LcnSPr7XYgYtVJc6wGe_tP2d9tjtgfIYY1FnED1N_oeA1y0ft96xRtM?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Real Estate",
    details: {
      chargingPiles: "Number of terminals: 36",
      energySaving: "Improves community new energy facilities",
      feedback: "Safe and reliable charging facilities, high satisfaction of residents."
    }
  },
  {
    title: "Shanghai Fangzhouyuan Community",
    location: "Shanghai",
    desc: "Aiming at the charging facility project introduced into the community, it solves the charging pain points of residents in Fangzhouyuan Community and helps the community's green upgrade.",
    tags: ["Residential Community", "Community Renovation", "Convenient Charging"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdq0CUPtCnR8rVGYHr-JfGE_U3kME6QknyxsfJTw4ThofZQ7IEhhQdVhFh89x5EjeBQg5rFQwmDGSUu9j7GJkIivwL_iMXyxgowqdQioRmjD863T7AM8qLhDLr3Ud0rBUns7aorFffl46TP9zltH0eUwGakbHg?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Real Estate",
    details: {
      chargingPiles: "Number of terminals: 7",
      energySaving: "Promotes the popularization of new energy vehicles in the community",
      feedback: "Effectively solved the urgent needs of residents."
    }
  },
  {
    title: "Anyang Fenghe Logistics Charging Station",
    location: "Anyang, Henan",
    desc: "Provides efficient charging services for Anyang Fenghe Logistics Park, meeting the high-frequency and high-power charging needs of logistics vehicles.",
    tags: ["Logistics Park", "Efficient Charging", "Logistics Fleet"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXez7NoC7XRct5N3zjZdoZkiYfcX8oQPPbg5HnvaoywM3ZIJOYKOwdZjk0WJDSxWRh-4mhIL_VmdzEcMdb3YpSIcwymKeuBfpPmS_uRpdTeOKKTcfDEbiMCKd9NJRGAF42OfLRZFIwAFA8cGGxudWC2BDYnO8g?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Logistics",
    details: {
      chargingPiles: "Number of terminals: 20",
      energySaving: "Reduces logistics transportation costs and promotes green logistics",
      feedback: "Fast charging speed, stable equipment operation."
    }
  },
  {
    title: "Mengneng Xilinhot Power Plant Heavy Truck Charging Station",
    location: "Xilingol League, Inner Mongolia",
    desc: "Provides exclusive charging services for the heavy truck transportation fleet of Mengneng Xilinhot Power Plant, helping the green logistics transformation of heavy industry.",
    tags: ["Heavy Truck Charging", "Power Plant Facilities", "Green Logistics"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdwmS1G0zpPxiAI8JkRT8o0-ChHBfucapU28Zxhplk3d4wst5Lmke23TX7ScG1y73GAuH4Li5knzf_7lnEayj8-kgoKRlohCl4epR27_BqqlMhRQyEcf6O2qWTBgM7SvuJR8BhGIke8vss7J4_nu6f1XMlX38w?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Logistics",
    details: {
      chargingPiles: "Number of terminals: 8",
      energySaving: "Significantly reduces carbon emissions from heavy trucks",
      feedback: "Adapts to cold climates, ensuring efficient operation of heavy trucks."
    }
  },
  {
    title: "Tangshan Zongheng Steel Charging Project",
    location: "Tangshan, Hebei",
    desc: "Provides charging solutions for transportation vehicles in Tangshan Zongheng Steel Plant, promoting low-carbon development in the steel industry.",
    tags: ["Steel Plant", "Transport Vehicles", "Low-carbon Development"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfzozusJHJzt2k-_dfOeTo0El3Haw1_5WGZC4WbBn_uE8r9390ioONypC-bdk7MKB7JxLzqHhlFfG172IAhYn2G5p4SpE94GuGRpgiktnWbELo6O6g8f6sPVDw_tQffisybtPME8qQoJlajMfYHgqnOZ8vSDuU?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Logistics",
    details: {
      chargingPiles: "Number of terminals: 10 dual-gun single piles",
      energySaving: "Helps steel enterprises achieve green transformation",
      feedback: "Durable equipment, fully adapting to the harsh environment of the plant."
    }
  },
  {
    title: "Guangxi Beibu Gulf Port",
    location: "Guangxi Zhuang Autonomous Region",
    desc: "Deploys an automated charging system at Guangxi Beibu Gulf Port, providing smart and efficient energy supply for port logistics vehicles and equipment.",
    tags: ["Port Terminal", "Automated Charging", "Smart Supply"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXchrSIBEC-ajf9QjsVb5WhOucS6eKxYwrSJCz468uhvlYZ4QN9wZ3zRHyTbGXbp1uLjcPO6Hh8SQ2-SeDXRbRBaAiwAQZOgf0tvR_Mwl_LvPMftTSodYQ82fxo18usM4tybHCJ8M7QZ1vtyFwgocFoNOINA9Bw?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Logistics",
    details: {
      chargingPiles: "Number of terminals: 6 sets of SCD automated charging systems",
      energySaving: "Promotes port logistics electrification and intelligence",
      feedback: "High degree of automation, significantly improving port operation efficiency."
    }
  },
  {
    title: "Ningbo Port Terminal Project",
    location: "Ningbo, Zhejiang",
    desc: "Provides large-scale charging services for container trucks and logistics vehicles at Ningbo Port Terminal, helping to build a green and smart port.",
    tags: ["Ningbo Port", "Container Truck Charging", "Smart Port"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdBc5fuDiDg1KKY1CNAErof-R7-wc_iCdm4i3gDN-giuxZWEoJ5CZ845KYc36KA0vgxTPP6w10I0DNn792d0mHxyZilawFfFs4szeYEFrTsPPYrWBrilaaFIKertPZAQh6-BDGvxaFoLqUmKHA8jKeGs-4lTw?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Logistics",
    details: {
      chargingPiles: "Number of terminals: 96",
      energySaving: "Significantly reduces port logistics carbon emissions",
      feedback: "Large-scale charging facilities, meeting the high-intensity operation needs of the port."
    }
  },
  {
    title: "Shanghai Pudong International Airport",
    location: "Shanghai",
    desc: "Provides comprehensive charging infrastructure for Shanghai Pudong International Airport, covering passenger parking lots and special vehicle charging needs.",
    tags: ["Pudong Airport", "Comprehensive Coverage", "Special Vehicles"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdcfpW-HdKeeX3qOGx2ZYzqSXxibKKtfCtdBmWdFBCUBj0Buy6ARR33LlNOoycucVuQMlVeDagqPRDL6rWROGKHVrMCFK595WhqCICXJylDbjwVyewoORHfWNwmUeq0VI2Acv97cZDBb4G9ryaVIrrMeddvWlk?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Airport",
    details: {
      chargingPiles: "Number of terminals: 52",
      energySaving: "Building a green aviation hub",
      feedback: "Greatly meets the complex and diverse charging needs of the airport."
    }
  },
  {
    title: "Beijing Daxing International Airport China Southern Airlines Base",
    location: "Beijing",
    desc: "Provides efficient charging services for aviation logistics and work vehicles at the China Southern Airlines Base of Beijing Daxing International Airport, ensuring airport operations.",
    tags: ["Daxing Airport", "China Southern Base", "Aviation Logistics"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdtsMDPYRhgz9eEQrE7qSPnnUCE6ex4fe40pV3RMYW2yPTwy03rLD7zcHQ8aYGlgCQDsL-cgMlgS1_Mq6kkmEUXCf2f7-uZSPQrrS1RMI1x_eeB7lyhhs0RYCBE9nkAwsZczUeYajYMwYhwL9_KoGpYvqDbLkc?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Airport",
    details: {
      chargingPiles: "Number of terminals: 71",
      energySaving: "Supports the green operation of modern airports",
      feedback: "Perfect charging facilities, excellent service experience."
    }
  },
  {
    title: "Qingdao TELD Park Smart Microgrid Charging Station",
    location: "Qingdao, Shandong",
    desc: "The smart microgrid charging demonstration project in TELD Park integrates group charging, special charging, and V2G systems to create a benchmark for green microgrids in enterprise parks.",
    tags: ["Smart Microgrid", "V2G System", "Enterprise Park"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcXkMCDRX8BycnI6VQRYyagmonBpcyomwM-kL99A3otil-YSATeFl379S8dWlArsfraIwojcx9M1e9mMEYJqwV-1oEGd2j01--5CjhcDneq7wNKvsBcLzkN6ZF47AELWunt5DEB_eAq54SPzP3dJjQ_1UaB_vE?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Real Estate",
    details: {
      chargingPiles: "Number of terminals: 2 sets of group charging systems, 2 sets of special charging, 1 set of V2G system, totaling 28 terminals",
      energySaving: "Achieves intelligent scheduling and efficient utilization of park energy",
      feedback: "The microgrid system operates stably, demonstrating strong technical strength."
    }
  },
  {
    title: "Baoding Low Carbon Park Smart Carport",
    location: "Baoding, Hebei",
    desc: "The smart carport project in Baoding Low Carbon Park integrates photovoltaics, energy storage, and charging facilities, providing green travel guarantees for tourists and surrounding residents.",
    tags: ["Low Carbon Park", "Smart Carport", "Solar Storage Charging"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXforw6RXcq6TLVY-n49fmS5jl5I43ln0xdiKkGnoly4gAtxiLKk7xgC9u8A13-XFVoin942yL5QG2p2_IHLZbJ-bK26jCGepbBX9VBwQYRg0w4kTIBuQUu2txVEddQNAxG-6qkgfcgCXnk7fOcbr9_11fUFRRU?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Microgrid",
    details: {
      chargingPiles: "Number of station terminals: 8",
      energySaving: "Station scale: Photovoltaic 15kWp, Energy Storage 20kWh, Power Distribution 200kVA",
      feedback: "Green and environmentally friendly, perfectly integrated with the park landscape."
    }
  },
  {
    title: "Shenzhen International Low Carbon City Solar Storage Charging and Discharging Integration Project",
    location: "Shenzhen, Guangdong",
    desc: "The solar storage charging and discharging integration demonstration project in Shenzhen International Low Carbon City demonstrates the application of advanced microgrid technology in urban low-carbon development.",
    tags: ["Low Carbon City", "Solar Storage Charging Discharging", "Integration"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXeOd_Fg2EX8PD4LPw9CmaIXhQHJTFVzGAWqE7eUy3lGly98-gZHtmyxTc1LtjZoUvbytsMEPUMq06dlvFrPXwLHz9gkIVeKXeEfvM5BxCFZjT0Hl-Nuqa_Vuur2yRbSdXBRESqBDiPfcwM-LKgFnh6t2WmSL4E?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Microgrid",
    details: {
      chargingPiles: "Number of terminals: 6",
      energySaving: "Station scale: Power Distribution 240KVA, Photovoltaic 110kWp, Energy Storage 234kWh, Discharging 360kW",
      feedback: "High system integration, excellent operating efficiency."
    }
  },
  {
    title: "Shanghai Fund Town Smart Carport",
    location: "Shanghai",
    desc: "The smart carport located in Shanghai Fund Town combines solar storage and charging technology to provide clean and efficient energy services for the financial park.",
    tags: ["Fund Town", "Smart Carport", "Financial Park"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXcxeV2c7Mnsbns1o1zCAl4gE1pEHt8OvvkvhEPYJV4Zv6vNY5tU--crAIndy8vb_cgGWLJ4ZqyzM1ljyMhGHJqXRRNJ9raNPU_0Bhz0pgeB4Si1nd9IFFv2fbhIowKYrmOCq6VDWX8tjSDvsk1ceLqklTHMjGA?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Microgrid",
    details: {
      chargingPiles: "Number of terminals: 8",
      energySaving: "Station scale: Photovoltaic 13kWp, Energy Storage 20kWh, Power Distribution 80kVA",
      feedback: "Modern design, meeting the charging needs of high-end business people in the park."
    }
  }
];

export const hongKongCasesEn: CaseDetail[] = [
  {
    title: "Lantau Island Penny's Bay Northbound Travel for Hong Kong Vehicles Charging Station",
    location: "Penny's Bay, Lantau Island, Hong Kong",
    desc: "In line with the 'Northbound Travel for Hong Kong Vehicles' policy, a charging station was set up at Penny's Bay, Lantau Island, providing convenient charging services to meet the charging needs of cross-border and local electric vehicles.",
    tags: ["Northbound Travel", "Public Charging", "Cross-border Service"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXc_O2qD5m2Kf5t8Z-4FWGmhyOCEkINV4UvK9GT_VTWEg_rzQzvV5xvrcaK43aK_i_IRtKeu4hu9dKDOrvCyWk3kSpXSVB5fjXKBn22PYA8IjuhZxbLnfbynhrg6RmyWYsNpSgIZjI-_w8CsqvglIuAFiA_-Tvc?key=7ewXKUOIU8nU-qIj2J_ImQ",
    category: "Public Fast Charging Station",
    details: {
      chargingPiles: "Number of terminals: 9",
      energySaving: "Supports green transportation interconnection in the Guangdong-Hong Kong-Macao Greater Bay Area",
      feedback: "Excellent location, greatly facilitating electric vehicle owners traveling between Guangdong and Hong Kong, with an efficient and stable charging experience."
    }
  }
];

export const internationalCasesEn: CaseDetail[] = [
  {
    title: "Kazakhstan Public Charging Station",
    location: "Kazakhstan",
    desc: "Public charging infrastructure construction project in Kazakhstan, providing strong support for the development of the local new energy vehicle market and promoting green travel in Central Asia.",
    tags: ["Central Asian Market", "Public Charging", "Infrastructure"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXf9OVCkeeVn39uVX74rGaDv2BCCPHCq56LVpzwMw_WpAK8UZdOETiqjeo8eGp76Mennd00JprcGad7549xEFESw4CaNyno9Hqtv4oyAKF_LMaL7sWMZzai14Sh8pQnBWNzkpMmoOQ?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "Various specifications of charging terminals",
      energySaving: "Promotes the popularization of new energy vehicles locally and reduces reliance on fossil fuels",
      feedback: "Played a key role in the promotion of local new energy vehicles."
    }
  },
  {
    title: "Malaysia Public Charging Station",
    location: "Malaysia",
    desc: "Public charging station project in Malaysia, optimizing equipment for tropical climate characteristics, providing stable and efficient charging services for local electric vehicles, and helping Southeast Asia's green travel transition.",
    tags: ["Southeast Asian Market", "Tropical Climate Adaptation", "Public Charging"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfGW3uqcPbjKpHuS_sAbFFa70wGcY0lwVFSjQuumaRAROMMLitHGL2Ld5O3cGJDmdqM3T64m_28uJo62DIiGyOWuGjAfQ5mx63M8KjQXoh4l7aH6p7NQsdREwwM2lzqoKxUU1QF?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "Customized charging piles adapted to high temperature and high humidity environments",
      energySaving: "Helps the development of green transportation in Malaysia",
      feedback: "The equipment operates stably in hot weather and responds quickly to services."
    }
  },
  {
    title: "Russia Public Charging Station",
    location: "Russia and surrounding Russian-speaking areas",
    desc: "Targeting the extreme cold climate in high-latitude areas, TELD has deployed charging equipment with super weather resistance. The equipment can still operate stably in extreme low temperatures of -30℃ to -50℃, providing reliable energy supply for Russia and surrounding Russian-speaking countries.",
    tags: ["Cold Environment", "Extreme Climate", "Russian-speaking Area"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXfcppXj8hk0mQNFGiE9uy5nra_il10I5Jg8O-e6aqDBVLeGIIaSF1cOGTMIPFJae_VCd7hTuBpX-vl4umCNQGWyCicbjZki6QxnDTHBbwdhDqhGUtQ_su0Bg7NZmdt1pHieqvWKzQ?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "Low-temperature resistant special charging equipment",
      energySaving: "Ensures the normal use of electric vehicles under extreme cold conditions",
      feedback: "It can still charge normally in extreme low temperatures, solving our worries."
    }
  },
  {
    title: "Qatar Bus Charging Station",
    location: "Qatar",
    desc: "Provides customized charging solutions for the Qatar public transportation system, adapting to the high temperature climate in the Middle East, and ensuring the efficient operation of bus fleets.",
    tags: ["Public Transportation", "Middle East Market", "High Temperature Adaptation"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXeC2qKO6cob-44QK2pcnki0DG81MDxt0fD4BDbONYqKKeAqmeRtQUufrI5tDhN_GzKRRZlUKec0BCMAVB9dH3x_Cc4lpkJk8azll1GBc8X04tXkGVDoJOVtZ9oz3rtB7uaWZrq_?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "High-power bus-specific charging terminals",
      energySaving: "Helps the green transformation of Qatar's public transportation",
      feedback: "Excellent high-temperature resistance, ensuring the stable operation of the bus system."
    }
  },
  {
    title: "UK London Bus Charging Station",
    location: "London, UK",
    desc: "Provides customized charging solutions for the London public transportation system, ensuring the efficient operation of pure electric bus fleets, and helping the development of green public transportation in Europe.",
    tags: ["European Market", "Public Transportation", "Bus Charging"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXc21PMziKytjrtmOS1pNPv5V3gx5UlEeAxCXlUu9efXWswHmUf1OYPv74Ee-GFeqaO0g8l93kbg0bWzbsghTwpZ1hGo4pLNpMHXe5DmeImcComjVUSfF9-mLWmZZWpwiFziBcz2?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "High-power bus-specific charging terminals",
      energySaving: "Supports London in achieving zero-carbon public transportation goals",
      feedback: "Perfectly compatible with the bus system, high charging efficiency."
    }
  },
  {
    title: "CRRC New Zealand Bus Project",
    location: "New Zealand",
    desc: "Cooperated with CRRC to provide supporting charging infrastructure for New Zealand electric buses, helping the electrification upgrade of the local public transportation system.",
    tags: ["Electric Bus", "Overseas Cooperation", "Infrastructure"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdLiGzMrqNKYJidd31oDGpXvMcwwvc9MDtvcgE1KrjseT4zSWvnTeKS64KxNcmM3KF4Sc-3rM8toZbzF8Wil73ghw1pY_RWzpklmH8JuRqs7bnWaoPVpMyTVMgznXkJQwrNhey0YA?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "High-power DC fast charging terminals",
      energySaving: "Supports New Zealand in achieving zero-carbon public transportation goals",
      feedback: "Perfectly compatible with the bus system, high charging efficiency."
    }
  },
  {
    title: "Germany BMW Headquarters Laboratory Equipment",
    location: "Multiple locations globally",
    desc: "Provides exclusive charging station construction services for the BMW brand, creating a high-quality charging experience to meet the charging needs of high-end brand car owners.",
    tags: ["Brand Exclusive", "High-end Experience", "Global Layout"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdqYoklehHXNTatweCKDSprnB2wCG8w53FCxcg0p8swqY8GTuJQkyrJRrBeXmK7loFFfWPnCIlgaHGmQJPSAUhxNwyA2kk3ZaN218AdmXXxio0-qyl4vgL6h1OxEfUtJrKDE_IU?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "Customized high-quality charging terminals",
      energySaving: "Promotes the popularization of high-end new energy vehicles",
      feedback: "Exquisite design, charging experience matches the brand positioning."
    }
  },
  {
    title: "Australia Mine Project",
    location: "Australia",
    desc: "Targeting the special environment of Australian mining areas, provides sturdy and durable charging equipment to provide reliable energy support for electric engineering vehicles in mining areas.",
    tags: ["Mining Application", "Special Vehicles", "Sturdy and Durable"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXestGoJe_2_qUpfwYhPl78XVURZE_n0sV40bLA6TLbHylMchp-Lj5yBqJB6Phbm-QgSB6Y5BW5oSv_H0WuJId6PdbsazVOMqILh4c5hGsmznHkPR-FRfUi_VpyqVA6dFTgefsCKqw?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "Dustproof and shockproof special charging terminals",
      energySaving: "Helps traditional mining achieve green and low-carbon transformation",
      feedback: "The equipment still performs excellently in harsh mining environments."
    }
  },
  {
    title: "Uzbekistan Project",
    location: "Uzbekistan",
    desc: "Charging infrastructure construction project in Uzbekistan, providing strong support for the development of the local new energy vehicle market.",
    tags: ["Central Asian Market", "Infrastructure", "Emerging Market"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXe5GpE2ql7Awbm_kRYzBbRlre4k1S8sx7JQLBmKV0vbw5FZE6CmUUbGnoNdtYwqM5jFzxFo6MTcRQvUT_hjPO3hMJFAn3XaPrukvYcq-skmn9l0-aMJNvoSRHjOed7NeWMvZW47Hg?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "Various specifications of charging terminals",
      energySaving: "Promotes the optimization of local energy structure",
      feedback: "Played a key role in the promotion of local new energy vehicles."
    }
  },
  {
    title: "Ecuador Project",
    location: "Ecuador",
    desc: "Charging station project deployed in Ecuador, committed to improving the local charging network and contributing to green travel in South America.",
    tags: ["South American Market", "Charging Network", "Green Travel"],
    image: "https://lh7-rt.googleusercontent.com/docsz/AD_4nXdgspcTCTnMwvtErWB11Jj-bCLgvVsgv9bUaE63L8KmZPvGtM6hJZZor5yQOYGOy86qmDWS3Tz71WRsP7FgSni69Y5gNtQjr-I0giM2dQaDxhdQXSZYMOAyvX-nXIGWzvXfQb_r5w?key=SIyLmeyd_R4-mtm9cVIzJA",
    details: {
      chargingPiles: "Public charging terminals",
      energySaving: "Promotes sustainable development in South America",
      feedback: "The construction of the charging station has greatly improved the convenience of local charging."
    }
  }
];

export const partnerCategoriesEn: PartnerCategory[] = [
  {
    title: "Power",
    iconName: "Zap",
    partners: ["State Grid", "China Southern Power Grid", "SPIC", "CLP"]
  },
  {
    title: "Automakers",
    iconName: "Car",
    partners: ["Porsche", "BMW", "Lotus", "Mercedes-Benz", "Volkswagen", "Volvo", "Ford", "GAC", "BYD", "SAIC", "FAW", "Audi", "NIO", "Xpeng", "Li Auto", "Zeekr", "Leapmotor", "Voyah", "Arcfox", "NETA", "Seres", "SANY", "Foton", "Shacman", "XCMG", "Yutong", "King Long", "Zhongtong", "Golden Dragon", "Ankai", "Skywell"]
  },
  {
    title: "Real Estate",
    iconName: "Building2",
    partners: ["Longfor", "China Resources Land", "Country Garden", "Sunac", "Shimao", "Vanke", "China Overseas Land & Investment", "China Merchants Shekou", "Poly Developments", "Datang Group", "Evergrande", "CFLD", "Dahua Group", "Hopson Development", "Risesun", "OCT", "Kaisa", "Times China"]
  },
  {
    title: "Aviation",
    iconName: "Plane",
    partners: ["Capital Airport", "Shanghai Airport Authority", "Baiyun Airport", "Shenzhen Airport", "Hangzhou Xiaoshan International Airport", "Sichuan Airlines", "Henan Airport Group", "Qingdao International Airport", "China Eastern Airlines", "Air China", "China Southern Airlines", "Chongqing Airport"]
  },
  {
    title: "Ports",
    iconName: "Ship",
    partners: ["Tianjin Port", "Yantai Port", "Qingdao Port", "Rizhao Port", "Guangzhou Port", "Ningbo Zhoushan Port", "Xiamen Port", "Dalian Port"]
  },
  {
    title: "Energy",
    iconName: "Battery",
    partners: ["CNPC", "Sinopec", "Shell", "Sinochem", "China Resources Gas", "China Gas", "Towngas", "China Huaneng", "Kunlun Energy", "China Huadian", "CGN", "PowerChina", "China Datang", "China Tower"]
  },
  {
    title: "Finance",
    iconName: "Landmark",
    partners: ["WeChat Pay", "Alipay", "JD", "UnionPay", "Bank of China", "Ping An Bank", "China Merchants Bank", "Agricultural Bank of China", "Shanghai Pudong Development Bank", "China Minsheng Bank", "China Construction Bank", "Bank of Communications"]
  },
  {
    title: "Mobility",
    iconName: "Navigation",
    partners: ["DiDi", "Amap", "Tencent Maps", "CaoCao Mobility", "T3 Mobility", "NavInfo", "Dida Chuxing", "Tuhu"]
  },
  {
    title: "Others",
    iconName: "MoreHorizontal",
    partners: ["Xinhua Net", "People's Daily Online", "Zhisland", "Huawei", "Sina", "Lalamove", "SF Express", "Tencent Net", "Toutiao", "Phoenix Net", "Guangming Online", "Ping An Insurance", "CCTV"]
  }
];
