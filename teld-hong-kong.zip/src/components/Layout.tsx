import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Mail, Zap, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();

  const navItems = [
    { name: t('nav.home'), path: '/' },
    { name: t('nav.about'), path: '/about' },
    { name: t('nav.products'), path: '/products' },
    { name: t('nav.solutions'), path: '/solutions' },
    { name: t('nav.cases'), path: '/cases' },
    { name: t('nav.contact'), path: '/contact' },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-800 bg-slate-50">
      {/* Navigation */}
      <nav className="bg-slate-900 shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <Link to="/" className="flex-shrink-0 flex items-center gap-3">
                <div className="w-32 h-16 flex items-center justify-center overflow-hidden">
                  <img 
                    src="https://lh7-rt.googleusercontent.com/docsz/AD_4nXfHWiZgOUJJN4lci27boJ4nJMjlAnllkCuPbWF8_O0sHW687oxiT3OFPz-cSE2lE1eI1bVvK6fXDkBjgdjfh6c42Ny6n3kHrL0N7Nw06zy-D-iV20d4ZAvJ_0ZcMvDaJz-hB7ltUDwRdtD-ksb-Gnj861okxPE?key=uDW8ifzWpheRosX4nA4uSg" 
                    alt="TELD Logo" 
                    className="w-full h-full object-contain p-2"
                    onError={(e) => {
                      const img = e.target as HTMLImageElement;
                      const parent = img.parentElement;
                      if (parent) {
                        img.style.display = 'none';
                        parent.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-zap text-white"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';
                      }
                    }}
                  />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-base text-blue-400 font-bold tracking-widest hidden sm:inline-block">{t('brand.name')}</span>
                </div>
              </Link>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-4 py-2 rounded-md text-base font-medium transition-colors ${
                    location.pathname === item.path
                      ? 'text-white bg-slate-800'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              
              <button
                onClick={() => setLanguage(language === 'zh' ? 'en' : 'zh')}
                className="ml-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700"
              >
                <Globe size={16} />
                <span className="text-sm font-medium">{language === 'zh' ? 'EN' : '中文'}</span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center gap-4">
              <button
                onClick={() => setLanguage(language === 'zh' ? 'en' : 'zh')}
                className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700"
              >
                <Globe size={14} />
                <span className="text-xs font-medium">{language === 'zh' ? 'EN' : '中文'}</span>
              </button>
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-slate-300 hover:text-white p-2"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-slate-900 border-t border-slate-800 overflow-hidden"
            >
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={`block px-3 py-2 rounded-md text-lg font-medium ${
                      location.pathname === item.path
                        ? 'text-white bg-slate-800'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-24 h-12 flex items-center justify-center overflow-hidden">
                  <img 
                    src="https://lh7-rt.googleusercontent.com/docsz/AD_4nXfHWiZgOUJJN4lci27boJ4nJMjlAnllkCuPbWF8_O0sHW687oxiT3OFPz-cSE2lE1eI1bVvK6fXDkBjgdjfh6c42Ny6n3kHrL0N7Nw06zy-D-iV20d4ZAvJ_0ZcMvDaJz-hB7ltUDwRdtD-ksb-Gnj861okxPE?key=uDW8ifzWpheRosX4nA4uSg" 
                    alt="TELD Logo" 
                    className="w-full h-full object-contain p-1.5"
                    onError={(e) => {
                      const img = e.target as HTMLImageElement;
                      const parent = img.parentElement;
                      if (parent) {
                        img.style.display = 'none';
                        parent.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-zap text-white"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';
                      }
                    }}
                  />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-base text-blue-400 font-bold tracking-widest">{t('brand.name')}</span>
                </div>
              </div>
              <p className="text-slate-400 mb-6 max-w-md leading-relaxed text-base">
                {t('footer.desc')}
              </p>
            </div>
            
            <div>
              <h3 className="text-white font-semibold text-lg mb-6">{t('footer.quickLinks')}</h3>
              <ul className="space-y-4 text-base">
                <li><Link to="/about" className="hover:text-blue-400 transition-colors">{t('nav.about')}</Link></li>
                <li><Link to="/products" className="hover:text-blue-400 transition-colors">{t('nav.products')}</Link></li>
                <li><Link to="/solutions" className="hover:text-blue-400 transition-colors">{t('nav.solutions')}</Link></li>
                <li><Link to="/cases" className="hover:text-blue-400 transition-colors">{t('nav.cases')}</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-semibold text-lg mb-6">{t('footer.contact')}</h3>
              <ul className="space-y-4 text-base">
                <li className="flex items-center gap-3">
                  <Phone size={20} className="text-blue-500" />
                  <a href="tel:+85264057279" className="hover:text-white transition-colors">+852 6405 7279</a>
                </li>
                <li className="flex items-center gap-3">
                  <Mail size={20} className="text-blue-500" />
                  <a href="mailto:teldhk@gmail.com" className="hover:text-white transition-colors">teldhk@gmail.com</a>
                </li>
                <li className="flex items-center gap-4 pt-2">
                  <a href="https://wa.me/85264057279" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center text-green-500 hover:bg-green-500 hover:text-white transition-all" aria-label="WhatsApp">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
                    </svg>
                  </a>
                  <a href="https://www.facebook.com/profile.php?id=61583207774081" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center text-blue-500 hover:bg-blue-600 hover:text-white transition-all" aria-label="Facebook">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                    </svg>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-base text-slate-500">
            <p>&copy; {new Date().getFullYear()} TELD Intelligent Energy Hong Kong Limited. All rights reserved.</p>
            <p>{t('footer.company')}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
