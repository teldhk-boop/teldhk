const fs = require('fs');
let content = fs.readFileSync('src/pages/Cases.tsx', 'utf8');

const domesticCasesRegex = /const domesticCases: CaseDetail\[\] = \[([\s\S]*?)\];\n\n  const internationalCases/;
const match = content.match(domesticCasesRegex);

if (!match) {
  console.error("Could not find domesticCases array");
  process.exit(1);
}

let domesticCasesStr = match[1];

const caseRegex = /\{\s*title:\s*"([^"]+)"[\s\S]*?details:\s*\{[\s\S]*?\}\s*\}/g;

let newDomesticCasesStr = domesticCasesStr.replace(caseRegex, (match, title) => {
  // 空港刪掉鄂州花湖機場充電站
  if (title === "鄂州花湖機場充電站") {
    return "DELETE_ME";
  }

  // 微網刪掉全部
  if (match.includes('category: "微網"')) {
    return "DELETE_ME";
  }

  return match;
});

newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME,\s*/g, '');
newDomesticCasesStr = newDomesticCasesStr.replace(/DELETE_ME/g, '');

const newCases = `,
    {
      title: "青島特銳德園區智能微網充電站",
      location: "山東省青島市",
      desc: "特銳德園區內的智能微網充電示範項目，集成了群充、特惠充及V2G系統，打造企業園區綠色微電網標杆。",
      tags: ["智能微網", "V2G系統", "企業園區"],
      image: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=2074&auto=format&fit=crop",
      category: "地產",
      details: {
        chargingPiles: "終端數量：2組群充系統、2組特惠充、1組V2G系統，共28個終端",
        energySaving: "實現園區能源智能調度與高效利用",
        feedback: "微網系統運行穩定，展現了強大的技術實力。"
      }
    },
    {
      title: "保定低碳公園智慧車棚",
      location: "河北省保定市",
      desc: "保定低碳公園內的智慧車棚項目，融合光伏、儲能與充電設施，為遊客及周邊居民提供綠色出行保障。",
      tags: ["低碳公園", "智慧車棚", "光儲充"],
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=80&w=2072&auto=format&fit=crop",
      category: "微網",
      details: {
        chargingPiles: "場站終端數 8個",
        energySaving: "場站規模：光伏 15kWp，儲能 20kWh，配電 200kVA",
        feedback: "綠色環保，與公園景觀完美融合。"
      }
    },
    {
      title: "深圳國際低碳城光儲充放一體化項目",
      location: "廣東省深圳市",
      desc: "深圳國際低碳城的光儲充放一體化示範項目，展現了先進的微電網技術在城市低碳發展中的應用。",
      tags: ["低碳城", "光儲充放", "一體化"],
      image: "https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?q=80&w=2071&auto=format&fit=crop",
      category: "微網",
      details: {
        chargingPiles: "終端數 6個",
        energySaving: "場站規模：配電 240KVA，光伏 110kWp，儲能 234kWh，放電 360kW",
        feedback: "系統集成度高，運行效率卓越。"
      }
    },
    {
      title: "上海基金小鎮智慧車棚",
      location: "上海市",
      desc: "位於上海基金小鎮的智慧車棚，結合光儲充技術，為金融園區提供清潔、高效的能源服務。",
      tags: ["基金小鎮", "智慧車棚", "金融園區"],
      image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=2069&auto=format&fit=crop",
      category: "微網",
      details: {
        chargingPiles: "終端數 8個",
        energySaving: "場站規模：光伏 13kWp，儲能 20kWh，配電 80kVA",
        feedback: "設計現代，滿足了園區高端商務人士的充電需求。"
      }
    }`;

newDomesticCasesStr = newDomesticCasesStr.trim();
if (newDomesticCasesStr.endsWith(',')) {
    newDomesticCasesStr = newDomesticCasesStr.slice(0, -1);
}
newDomesticCasesStr += newCases;

content = content.replace(domesticCasesStr, newDomesticCasesStr + '\n  ');

fs.writeFileSync('src/pages/Cases.tsx', content);
console.log('Update complete');
